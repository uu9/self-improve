#include <string>
#include <Eigen/Dense>
#include <matioCpp/matioCpp.h>

Eigen::MatrixXd read_mat(std::string filepath, std::string field);
