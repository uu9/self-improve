#include <iostream>
#include <read_mat.h>

Eigen::MatrixXd read_mat(std::string filepath, std::string field)
{
    matioCpp::File input(filepath.data());
    // You can check if input is open with the isOpen() method
    matioCpp::MultiDimensionalArray<double> Array = input.read(field.data()).asMultiDimensionalArray<double>();
    // cout<<Array.dimensions().size()<<endl;
    // cout<<Array({0, 0})<<endl;
    return matioCpp::to_eigen(Array);;
}
