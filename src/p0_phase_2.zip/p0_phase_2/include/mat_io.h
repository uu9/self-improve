#include <string>
#include <Eigen/Core>
#include <Eigen/Dense>


bool make_arr(Eigen::MatrixXd mat, double* arr, size_t rows, size_t cols);
double* make_arr(Eigen::MatrixXd mat, size_t rows, size_t cols);
Eigen::MatrixXd make_mat(double* arr, size_t rows, size_t cols);