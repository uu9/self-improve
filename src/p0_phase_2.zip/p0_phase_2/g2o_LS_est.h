#ifndef G2O_LS_EST_H
#define G2O_LS_EST_H

#ifdef __cplusplus
extern "C"
{
#endif    

int g2o_LS_est(double* ret_p, double *x_p, double *y_p, double *init_guess_p,
               double g2o_noise, int meas_num);

#ifdef __cplusplus
}
#endif
#endif
