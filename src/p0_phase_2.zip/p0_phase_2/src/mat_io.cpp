#include <iostream>
#include <mat_io.h>
#include <Eigen/Core>


bool make_arr(Eigen::MatrixXd mat, double* arr, size_t rows, size_t cols){
    for(int i=0;i<cols;i++){
        for(int j=0;j<rows;j++){
            arr[i*rows+j] = mat(j, i);
        }
    }
    return true;
}

double* make_arr(Eigen::MatrixXd mat, size_t rows, size_t cols){
    double* arr =  new double[rows*cols];
    for(int i=0;i<cols;i++){
        for(int j=0;j<rows;j++){
            arr[i*rows+j] = mat(j, i);
        }
    }
    return arr;
}

Eigen::MatrixXd make_mat(double* arr, size_t rows, size_t cols){
    Eigen::MatrixXd mat(rows, cols);
    for(int i=0;i<cols;i++){
        for(int j=0;j<rows;j++){
            mat(j, i) = arr[i*rows+j];
        }
    }
    return mat;
}
