#include <Eigen/Core>
#include <chrono>
#include <cmath>
#include <g2o/core/base_binary_edge.h>
#include <g2o/core/base_unary_edge.h>
#include <g2o/core/base_vertex.h>
#include <g2o/core/block_solver.h>
#include <g2o/core/g2o_core_api.h>
#include <g2o/core/optimization_algorithm_dogleg.h>
#include <g2o/core/optimization_algorithm_gauss_newton.h>
#include <g2o/core/optimization_algorithm_levenberg.h>
#include <g2o/solvers/csparse/linear_solver_csparse.h>
#include <g2o/solvers/dense/linear_solver_dense.h>
#include <g2o/core/optimization_algorithm_factory.h>
#include <iostream>

#include <mat_io.h>
#include <g2o_LS_est.h>

using namespace std;

// #define gen_rand() (1 - 2 * rand() / double(RAND_MAX))
#define GEN_NCL_Jacobian true
#define GEN_CL_Jacobian true

// 曲线模型的顶点，模板参数：优化变量维度和数据类型
class LocVertex : public g2o::BaseVertex<2, Eigen::Vector2d>
{
  public:
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW

    // 重置
    virtual void setToOriginImpl() override
    {
        _estimate << 0, 0;
    }

    // 更新
    virtual void oplusImpl(const double *update) override
    {
        _estimate += Eigen::Vector2d(update);
    }

    // 存盘和读盘：留空
    virtual bool read(istream &in)
    {
        return true;
    }

    virtual bool write(ostream &out) const
    {
        return true;
    }
};

// 误差模型 模板参数：观测值维度，类型，连接顶点类型
class NCLEdge : public g2o::BaseUnaryEdge<1, double, LocVertex>
{
  public:
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW

    NCLEdge(double x) : BaseUnaryEdge(), _x(x)
    {
    }

    // 计算曲线模型误差
    virtual void computeError() override
    {
        const LocVertex *v = static_cast<const LocVertex *>(_vertices[0]);
        const Eigen::Vector2d est = v->estimate();

        // a*x+b - y
        _error(0) = abs(est(0) * _x + est(1) - _measurement);
    }

// 计算雅可比矩阵
#if (!GEN_NCL_Jacobian)
    virtual void linearizeOplus() override
    {
    }
#endif

    virtual bool read(istream &in)
    {
        return true;
    }

    virtual bool write(ostream &out) const
    {
        return true;
    }

  public:
    double _x; // x 值， y 值为 _measurement
};

Eigen::Vector2d LS_fit(Eigen::VectorXd x, Eigen::VectorXd y, Eigen::Vector2d init_guess, double g2o_noise, int meas_num)
{
    int N = 1;
    double w_sigma = g2o_noise; // 噪声Sigma值

    
    // 构建图优化，先设定g2o
    typedef g2o::BlockSolver<g2o::BlockSolverTraits<2, 1>> BlockSolverType; // 每个误差项优化变量维度，误差值维度
    typedef g2o::LinearSolverDense<BlockSolverType::PoseMatrixType> LinearSolverType; // 线性求解器类型

    // 梯度下降方法，可以从GN, LM, DogLeg 中选
    auto solver = new g2o::OptimizationAlgorithmGaussNewton(
        std::make_unique<BlockSolverType>(std::make_unique<LinearSolverType>()));
    g2o::SparseOptimizer optimizer; // 图模型
    optimizer.setAlgorithm(solver); // 设置求解器
    optimizer.setVerbose(true);     // 打开调试输出
    

    //  // setup the solver
    // g2o::SparseOptimizer optimizer;
    // optimizer.setVerbose(true);

    // // allocate the solver
    // g2o::OptimizationAlgorithmProperty solverProperty;
    // optimizer.setAlgorithm(
    //     g2o::OptimizationAlgorithmFactory::instance()->construct("lm_dense",
    //                                                             solverProperty));

    vector<LocVertex *> v_set;
    v_set.reserve(N);

    // 往图中增加顶点
    for (int i = 0; i < N; i++)
    {
        LocVertex *v = new LocVertex();
        v->setId(i);
        v->setEstimate(init_guess);
        v->setFixed(false);
        optimizer.addVertex(v);
        v_set.push_back(v);
    }

    cout << "Add Vertex Finished" << endl;

    // 往图中增加边
    // 非协同
    int edge_id = 0;
    for (int p = 0; p < N; p++)
    {
        for (int edge_k = 0; edge_k < meas_num; edge_k++)
        {
            NCLEdge *edge = new NCLEdge(x(edge_k));
            edge->setId(edge_id);
            edge->setVertex(0, v_set[p]);
            edge->setMeasurement(y(edge_k)); // 观测数值
            edge->setInformation(Eigen::Matrix<double, 1, 1>::Identity() * 1 /
                                 (w_sigma * w_sigma)); // 信息矩阵：协方差矩阵之逆
            optimizer.addEdge(edge);
            edge_id++;
        }
    }

    cout << "Add NCL edge Finished" << endl;

    cout << endl;
    // 执行优化
    cout << "start optimization" << endl;
    // chrono::steady_clock::time_point t1 = chrono::steady_clock::now();
    optimizer.initializeOptimization();
    optimizer.optimize(10);
    // chrono::steady_clock::time_point t2 = chrono::steady_clock::now();
    // chrono::duration<double> time_used = chrono::duration_cast<chrono::duration<double>>(t2 - t1);
    // cout << "solve time cost = " << time_used.count() << " seconds. " << endl;

    // 输出优化值
    int max_num = N;
    for (int i = 0; i < max_num; i++)
    {
        cout << endl;
        Eigen::Vector2d est = v_set[i]->estimate();
        cout << est << endl;
    }

    return v_set[0]->estimate();
}

// int main(int argc, char** argv)
// {
//     // y = x

//     // system model
//     // y = a*x+b

//     int meas_num = 10;
    
//     Eigen::VectorXd x(10);
//     x << 0, 1, 2, 3, 4, 5, 6, 7, 8, 9;
//     Eigen::VectorXd y = x;

//     Eigen::Vector2d init_guess = {1.2, 0.2};
//     double g2o_noise = 1;

//     cout<<x<<endl<<y<<endl<<init_guess<<endl;
//     LS_fit(x, y, init_guess, g2o_noise, meas_num);
// }

int g2o_LS_est(double* ret_p, double *x_p, double *y_p, double *init_guess_p,
               double g2o_noise, int meas_num)
{
    // Eigen::VectorXd &x, Eigen::VectorXd &y, Eigen::Vector2d &init_guess, double g2o_noise, int meas_num
    Eigen::MatrixXd x = make_mat(x_p, meas_num, 1);
    Eigen::MatrixXd y = make_mat(y_p, meas_num, 1);
    Eigen::MatrixXd init_guess = make_mat(init_guess_p, 2, 1);
    Eigen::Vector2d ret = LS_fit(x, y, init_guess, g2o_noise, meas_num);
    make_arr(ret, ret_p, 2, 1);
    return 0;
}