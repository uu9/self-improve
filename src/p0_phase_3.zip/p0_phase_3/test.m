clc;clear;close all;

x = [0;1;2;3;4;5;6;7;8;9];
y = x;
init_guess = [1.2;0.2];
meas_num = 2;
g2o_noise = 1;

[ret] = get_g2o_LS_est(x, y, init_guess, g2o_noise, meas_num);

ret