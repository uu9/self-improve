function [ret_est]=get_g2o_LS_est(x, y, init_guess, g2o_noise, meas_num)

header_name = "g2o_LS_est";
func_name = "g2o_LS_est";
lib_name = "libg2o_LS_est";

% system("ldd "+lib_name+".so")

if not(libisloaded(lib_name))
    loadlibrary(lib_name, header_name);
end

% libfunctions(lib_name)
% libfunctionsview(lib_name)

ret_ptr = libpointer('doublePtr', zeros(2, 1));

init_guess_ptr = libpointer('doublePtr', init_guess);

x_ptr = libpointer('doublePtr', x);
y_ptr = libpointer('doublePtr', y);

res = calllib(lib_name, func_name, ...
    ret_ptr, ...
    x_ptr, y_ptr, init_guess_ptr, double(g2o_noise), int32(meas_num));

ret_struct = ret_ptr.get();
ret_est = ret_struct.Value;

if libisloaded(lib_name)
    unloadlibrary(lib_name);
end

% ret = libpointer('doublePtr', res);

end